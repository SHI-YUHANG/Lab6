#include <stdio.h>
#include <stdlib.h>

void get_env(char *name)
{
   char *value = (char *)getenv(name);

   if(value){
      printf("  Name:    %s\n", name);
      printf("  Value:   %s\n", value);
      printf("  Address: 0x%x\n", (unsigned int)value);
      printf("----------------------\n");
   }

}

int main()
{
   get_env("MYSHELL");
   get_env("MYSHELL2");
   return 1;
}

